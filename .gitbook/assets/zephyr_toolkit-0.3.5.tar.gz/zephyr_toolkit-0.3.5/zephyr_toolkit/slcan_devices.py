import json
import sys
import pkg_resources
import serial.tools.list_ports as serial_list_ports
  
class slcan_devices:  
      
    def __init__(self):  
        self.__slcan_devices_file = pkg_resources.resource_filename("zephyr_toolkit", 'resources/slcan_devices.json')

    # Creates an empty JSON file with an empty 'slcan_devices' list.  
    def __cfg_create(self):  # Private method to create an empty file  
        with open(self.__slcan_devices_file, 'w') as file:    
            json.dump({"slcan_devices": []}, file, indent=4)
  
    # Returns a list of devices from the JSON file.  
    # If the file is not found or JSON decoding fails, an empty list is returned.  
    def cfg_list(self):  
        try:  
            with open(self.__slcan_devices_file, 'r') as file:    
                data = json.load(file)  
            return data['slcan_devices']  
        except (FileNotFoundError, json.JSONDecodeError):  
            return []
    
    # Adds a new device configuration to the JSON file.  
    # If a device with the same VID and PID already exists, False is returned.  
    # If the file is not found or JSON decoding fails, an empty file is created   
    # and the device configuration is added to it. True is returned on success.  
    def add_cfg(self, vid, pid):    
        try:  
            with open(self.__slcan_devices_file, 'r+') as file:    
                data = json.load(file)    
                for device in data['slcan_devices']:  
                    # Device already exists  
                    if device['vid'] == vid and device['pid'] == pid:  
                        raise Exception('device already exists')
                data['slcan_devices'].append({"vid": vid, "pid": pid})
                file.seek(0)    
                json.dump(data, file, indent=4)    
                file.truncate()  
                return True
        except (FileNotFoundError, json.JSONDecodeError):  
            # Create an empty file if it doesn't exist
            self.__cfg_create()    
            with open(self.__slcan_devices_file, 'r+') as file:    
                # Initialize data with an empty list  
                data = {"slcan_devices": []}  
                # Add device to empty file  
                data['slcan_devices'].append({"vid": vid, "pid": pid})  
                file.seek(0)    
                json.dump(data, file, indent=4)    
                file.truncate()    
            return True

    # Removes a device configuration from the JSON file based on its VID and PID.  
    def remove_cfg(self, vid, pid):
        try:
            with open(self.__slcan_devices_file, 'r+') as file:    
                data = json.load(file)    
                devices = data['slcan_devices']    
                devices[:] = [d for d in devices if not (d['vid'] == vid and d['pid'] == pid)]    
                file.seek(0)    
                json.dump(data, file, indent=4)    
                file.truncate()
            return True
        except (FileNotFoundError, json.JSONDecodeError):
            self.__cfg_create()
            raise Exception('device not found')
      
    # Returns a list of available serial devices based on the VID and PID of the device.
    def available_devices(self):
        devices = []
        cfg = self.cfg_list()
        ports = serial_list_ports.comports()

        for port in ports:
            if hasattr(port, 'vid') and hasattr(port, 'pid'):
                for usb in cfg:
                    if usb['vid'] == port.vid and usb['pid'] == port.pid:
                        devices.append(port.device)
        return devices


def slcan_device_add(args):
    try:
        slcan_devices().add_cfg(args.vid, args.pid)
    except Exception as e:
        print(e)
        exit(-1)

def slcan_device_remove(args):
    try:
        slcan_devices().remove_cfg(args.vid, args.pid)
    except Exception as e:
        print(e)
        exit(-1)

def slcan_show_devices(args):
    devices = slcan_devices().available_devices()
    for i,device in enumerate(devices):
        print(f'{i+1}. {device}')

import argparse  
  
def slcan_usb_id(val):
    ret = 0
    try:  
        ret = int(val, 16)
        if ret < 0 or ret > 0xffff:
            raise Exception(f"{val} out of id range")
    except Exception as e:  
        print(e)
        exit(-1)
    return ret  

def add_slcan_remove_parser(subparsers):
    parser = subparsers.add_parser('remove', help='remove slcan device')
    parser.add_argument('pid', type=slcan_usb_id, help='the vid of slcan device')
    parser.add_argument('vid', type=slcan_usb_id, help='the pid of slcan device')
    parser.set_defaults(func=slcan_device_remove)

def add_slcan_add_parser(subparsers):
    parser = subparsers.add_parser('add', help='add slcan device')
    parser.add_argument('pid', type=slcan_usb_id, help='the vid of slcan device')
    parser.add_argument('vid', type=slcan_usb_id, help='the pid of slcan device')
    parser.set_defaults(func=slcan_device_add)

def add_slcan_show_parser(subparsers):
    parser = subparsers.add_parser('show', help='show available slcan device')
    parser.set_defaults(func=slcan_show_devices)

def add_parser(subparsers):
    slcan_subparser = subparsers.add_parser('slcan', help='slcan device tools')
    slcan_subparsers = slcan_subparser.add_subparsers(title='slcan commands')
    add_slcan_add_parser(slcan_subparsers)
    add_slcan_remove_parser(slcan_subparsers)
    add_slcan_show_parser(slcan_subparsers)
