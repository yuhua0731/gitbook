import os
import argparse
import json
import struct
import shutil
import pkg_resources
from . import zephyr_lfs
from littlefs import LittleFS

class settings:
    __config_file = ""
    __output_file = ""
    __format_dict = {"int8": "b", 
                     "uint8": "B", 
                     "int16": "h", 
                     "uint16": "H", 
                     "int32": "i", 
                     "uint32": "I", 
                     "int64": "q", 
                     "uint64": "Q", 
                     "bool": "?", 
                     "string": "s", 
                     "float": "f", 
                     "double": "d"}
    __recursive_depth = 0

    def __init__(self, input_file, output_file):
        self.__config_file = input_file
        self.__output_file = output_file

    def __encode_length(self, encoded_array):
        return struct.pack("H", len(encoded_array))

    def __encode_key(self, key):
        return key.encode("utf-8") + b"="
    
    def __encode_value(self, fmt, value):
        array = bytearray()

        if type(value) == list:
            if fmt == "s":
                for item in value:
                    array += item.encode("utf-8") + b"\0"
            else:
                for item in value:
                    array += struct.pack(fmt, item)
        else:
            if fmt == "s":
                array += value.encode("utf-8") + b"\0"
            else:
                array += struct.pack(fmt, value)
        
        return array

    def __encode(self, key, value, type):
        if type in self.__format_dict:
            return self.__encode_key(key) + self.__encode_value(self.__format_dict[type], value)
        else:
            raise ValueError("Invalid type: " + type + " for key: " + key + " in config")

    def __encode_node(self, key, node):
        array = bytearray()
        self.__recursive_depth += 1

        if "value" in node and "type" in node:
            print("Encoding: " + key)

            if self.__recursive_depth > 8:
                raise ValueError("The depth of configuration should be less than 8")

            ret = self.__encode(key, node["value"], node["type"])
            if len(ret) > 72:
                raise ValueError("The name of key should be less than 72 bytes")
            
            array += self.__encode_length(ret)
            array += ret
            self.__recursive_depth -= 1
            return array
        elif type(node) is dict:
            for subkey, subnode in node.items():
                array += self.__encode_node(key + '/' + subkey, subnode)
            self.__recursive_depth -= 1
            return array
        else:
            raise ValueError("Invalid node, missing value or type")
    
    """
    Export the configuration to a binary file.

    Args:
        None
    Returns:
        None
    """
    def export(self):
        encode_array = bytearray()
        data = json.load(open(self.__config_file))
        self.__recursive_depth = 0

        for key, node in data.items():
            encode_array += self.__encode_node(key, node)
        
        with open(self.__output_file, "wb") as f:
            f.write(encode_array)
            f.close()

""" 
Replace the suffix of the input file name with .bin.

Args:
    input_filename: The input file name.
Returns:
    The output file name.
"""
def replace_suffix(input_filename):
    base_name = os.path.basename(input_filename)
    if base_name.endswith(".json"):
        return base_name[:-5] + ".bin"
    else:
        raise ValueError("Invalid input file extension. Expected .json")

"""
Add cli input and output file names to a dictionary.

Args:
    input_files: The input file names.
Returns:
    A dictionary of input file names and output file names.
"""
def convert_inputs_to_dict(inputs):
    ret = dict()

    if len(inputs) == 0:
        return None

    for i in range(len(inputs)):
        # If the input is a json file, check if it exists. Otherwise, skip it.
        if inputs[i].endswith(".json"):
            if os.path.exists(inputs[i]) == False:
                raise ValueError("Input file " + inputs[i] + " not found")
        else:
            continue
        
        # If the next input is not a json file, it is the output file name. Otherwise, it is the input file name.
        if i + 1 < len(inputs) and not inputs[i + 1].endswith(".json"):
            output_file = inputs[i + 1]

            if os.path.dirname(output_file) != "":
                raise ValueError("Output file name should not contain a path")
            
            ret[inputs[i]] = output_file
        else:
            ret[inputs[i]] = replace_suffix(inputs[i])
        
        print(f"Input file: {inputs[i]}, Output file: {ret[inputs[i]]}")

    return ret

def settings_json_to_image(inputs, image, cfg, output):
    # 检查输入文件是否存在，如果不存在则退出程序，如果存在则进行下一步操作。
    if not inputs:
        raise Exception("No input files")

    # 设置默认输出目录
    if (output == None):
        output = os.getcwd() + '/littlefs'

    # 创建输出目录
    if not os.path.exists(output):
        os.mkdir(output)
    else:
        raise ValueError("Output path (" + output + ") already exists")
    
    # 为 output_folder 增加 /
    if output[-1] != '/':
        output += '/'

    # 处理 json 文件，将其转换成 bin 文件，并将其导出到 output_folder 中
    ret = convert_inputs_to_dict(inputs)
    # 导出配置文件
    for key in ret.keys():
        path = output + ret[key]
        settings(key, path).export()
    
    # 拷贝整个目录下的文件到镜像中
    fs = zephyr_lfs.zephyr_lfs(cfg)
    if (os.path.exists(image)):
        fs.mount(image)
    fs.copy_recursive(output.split(), '/')
    fs.export(image)
    
    # 删除输出目录
    shutil.rmtree(output)

def settings_json_to_bin(inputs, output):
    if (output == None):
        output = os.getcwd()

    # Add slash to the end of output_folder if it does not end with /.
    if output[-1] != '/':
        output += '/'

    ret =  convert_inputs_to_dict(inputs)
    for key in ret.keys():
        path = output + ret[key]
        settings(key, path).export()

def settings_export_template(output):
    path = pkg_resources.resource_filename("zephyr_toolkit", "resources/settings_template.json")
    with open(path, 'rb') as ifile:
        content = ifile.read()
        with open(output, 'wb') as ofile:
            ofile.write(content)

def settings_parse(args):
    try:
        if args.template:
            settings_export_template(args.template)

        if (args.input):
            if(args.image):
                settings_json_to_image(args.input, args.image, args, args.output)
            else:
                settings_json_to_bin(args.input, args.output)
    except Exception as e:
        print(e)
        exit(-1)

def add_settings_parser(subparsers):
    help = "convert json file to settings file"
    epilog = ["example:",
              "        # connvert json file to settings file, format: json",
              "        # format: a json file followed by a non-json suffix name as the output filename, ",
              "        # if there is no output filename, automatically replace the json file suffix with bin as the output filename",
              "        ztk settings config1.json config2.json config3.json",
              "        ztk settings config1.json config1.bin",
              "        ztk settings config1.json config1.bin config2.json\n",
              "        # convert config1.json to settings.conf, then move settings.conf to lfs.bin:/",
              "        ztk settings config1.json settings.conf -i lfs.bin\n",
              "        # export settings.json template",
              "        ztk settings --template=config.json\n"]
    parser = subparsers.add_parser('settings', formatter_class=argparse.RawTextHelpFormatter, help=help, epilog='\n'.join(epilog))
    parser.add_argument('input', type=str, nargs='*', help="json config file")
    parser.add_argument('-o', '--output', metavar='', type=str, default=None, help="settings file output folder")
    parser.add_argument('-i', '--image', metavar='', type=str, default=None, help="littlefs path")
    parser.add_argument('--template', metavar='', default='', help="export settings template")
    zephyr_lfs.littlefs_add_options(parser)
    parser.set_defaults(func=settings_parse)

def add_parser(subparsers):
    add_settings_parser(subparsers)