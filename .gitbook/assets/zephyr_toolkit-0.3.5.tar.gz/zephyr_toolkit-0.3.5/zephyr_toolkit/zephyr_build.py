import subprocess
import os
import sys
import argparse
import shutil 
import json
import pkg_resources

COMPILE_CFG="compile.json"

def build_bootloader(args):
    # 目标板名称
    target_board = args.board
    # 目标板根目录
    boards_root_path = ''
    # 源码路径，默认为空
    source_path = ''
    # 签名文件路径
    signature_file = ''
    # 编译输出目录
    build_output_path = args.build

    # 签名文件路径, bootloader 目录下的root-rsa-2048.pem文件
    if (args.signature_file):
        signature_file = args.signature_file

    # 输出文件名称, 默认为目标板名称
    if (args.kernel_output):
        kernel_output_name = args.kernel_output
    else:
        kernel_output_name = args.type

    # 目标板目录, 默认为当前目录下的root目录, 不指定则从工作区中查找
    if (args.boards_root):
        if (os.path.isabs(args.boards_root)):
            boards_root_path = args.boards_root
        else:
            boards_root_path = subprocess.run(['pwd'], stdout=subprocess.PIPE).stdout.decode('utf-8').strip() + '/' + args.boards_root

        if (not os.path.exists(boards_root_path)):
            raise Exception('目标板目录: ' + boards_root_path + '不存在')
    
    # 指定源码路径
    if (args.source):
        if (not os.path.exists(args.source)):
            raise Exception('MCUBOOT源码目录: ' + args.source + '不存在')
        else:
            source_path = args.source
    else:
        workspace_absolute_path = subprocess.run(['west', 'topdir'], stdout=subprocess.PIPE)
        mcuboot_relative_path = subprocess.run(['west', 'list', 'mcuboot', '-f', '{path}'], stdout=subprocess.PIPE)
        if (mcuboot_relative_path.returncode != 0 or workspace_absolute_path.returncode != 0):
            print(workspace_absolute_path.stderr.decode('utf-8') , file=sys.stderr, end='')
            print(mcuboot_relative_path.stderr.decode('utf-8'), file=sys.stderr, end='')
            raise Exception('默认MCUBOOT不存在')
        else:
            source_path = workspace_absolute_path.stdout.decode('utf-8').strip() + '/' + mcuboot_relative_path.stdout.decode('utf-8').strip() + '/boot/zephyr'

    # 初始化编译命令
    west_build_cmd = ['west', 'build']
    west_build_cmd.append(source_path)
    if (boards_root_path):
        west_build_cmd.append("-DBOARD_ROOT=" + boards_root_path)
    west_build_cmd.append('-b')
    west_build_cmd.append(target_board)
    west_build_cmd.append('-d')
    west_build_cmd.append(build_output_path)
    west_build_cmd.append('-DCONFIG_KERNEL_BIN_NAME=' + '\\\"' + kernel_output_name + '\\\"')
    if (signature_file):
        west_build_cmd.append('-DCONFIG_BOOT_SIGNATURE_TYPE_RSA=y')
        west_build_cmd.append('-DCONFIG_BOOT_SIGNATURE_KEY_FILE=' + '\\\"' + signature_file + '\\\"')
    west_build_cmd = west_build_cmd + args.extra_param
    if (args.pristine != 'never'):
        west_build_cmd.append('-p')
        west_build_cmd.append(args.pristine)
    # print(' '.join(west_build_cmd))
    return os.system(' '.join(west_build_cmd))


def build_app(args):
    # 目标板名称
    target_board = args.board
    # 目标板根目录
    boards_root_path = ''
    # 源码路径，默认为当前路径
    source_path = '.'
    # 签名文件
    signature_file = ''
    # 编译输出目录
    build_output_path = args.build

    # 签名文件路径, bootloader 目录下的root-rsa-2048.pem文件
    if (args.signature_file):
        signature_file = 'bootloader/mcuboot/' + args.signature_file
    
    # 输出文件名称, 默认为目标板名称
    if (args.kernel_output):
        kernel_output_name = args.kernel_output
    else:
        kernel_output_name = args.type
    
    # 目标板目录, 默认为当前目录下的root目录, 不指定则从工作区中查找
    if (args.boards_root):
        if (os.path.isabs(args.boards_root)):
            boards_root_path = args.boards_root
        else:
            boards_root_path = subprocess.run(['pwd'], stdout=subprocess.PIPE).stdout.decode('utf-8').strip() + '/' + args.boards_root

        if (not os.path.exists(boards_root_path)):
            raise Exception('目标板目录: ' + boards_root_path + '不存在')
    
    # 指定源码路径, 不指定为当前路径
    if (args.source):
        if (not os.path.exists(args.source)):
            raise Exception('APP源码目录: ' + args.source + '不存在')
        else:
            source_path = args.source

    # 初始化编译命令
    west_build_cmd = ['west', 'build']
    west_build_cmd.append(source_path)
    if (boards_root_path):
        west_build_cmd.append("-DBOARD_ROOT=" + boards_root_path)
    west_build_cmd.append('-b')
    west_build_cmd.append(target_board)
    west_build_cmd.append('-d')
    west_build_cmd.append(build_output_path)
    west_build_cmd.append('-DCONFIG_KERNEL_BIN_NAME=' + '\\\"' + kernel_output_name + '\\\"')
    if (signature_file):
        west_build_cmd.append('-DCONFIG_BOOTLOADER_MCUBOOT=y')
        west_build_cmd.append('-DCONFIG_MCUBOOT_SIGNATURE_KEY_FILE=' + '\\\"' + signature_file + '\\\"')
    west_build_cmd = west_build_cmd + args.extra_param
    if (args.pristine != 'never'):
        west_build_cmd.append('-p')
        west_build_cmd.append(args.pristine)
    # print(' '.join(west_build_cmd))
    return os.system(' '.join(west_build_cmd))

def get_value_with_type_check(d, key, default, expected_type):  
    value = d.get(key, default)  
    if not isinstance(value, expected_type):  
        return default  
    return value

def read_compile_config(path):
    try:
        with open(path, 'r') as file:    
            return json.load(file)
    except:
        return dict()

def export_compile_template(output):
    path = pkg_resources.resource_filename("zephyr_toolkit", "resources/compile_template.json")
    with open(path, 'rb') as ifile:
        content = ifile.read()
        with open(output, 'wb') as ofile:
            ofile.write(content)

def zephyr_build(args):
    ret = None
    app_args = argparse.Namespace()
    bootloader_args = argparse.Namespace()

    try:
        if args.template:
            export_compile_template(args.template)
            return

        if not os.path.exists(COMPILE_CFG):
            raise Exception('文件' + COMPILE_CFG + ' 不存在')
        with open(COMPILE_CFG, 'r') as file:    
            ret = json.load(file)
        
        # 设置目标板名称，首先从命令行获取，如果命令行不存在使用配置文件中 default_board 属性值，如果都不存在，则抛出异常。
        if not args.board:
            if not ret.get('default_board'):
                raise Exception('请指定需要编译的目标板')
            args.board = ret.get('default_board')
        app_args.board = args.board
        bootloader_args.board = args.board
        
        # 检查 bootloader 和 app 中的属性是否存在，如果不存在，则抛出异常。
        if (args.type == 'bootloader') and not ret.get('bootloader'):
            raise Exception("bootloader 属性不存在")

        if not ret.get('app'):
            raise Exception("app 属性不存在")
        
        if ret.get('bootloader'):
            bootloader = ret.get('bootloader')
            # 检查bootloader 中 source 指定的路径是否是一个目录
            bootloader_args.source = bootloader.get('source', '')
            if bootloader_args.source and not os.path.isdir(bootloader_args.source):
                raise Exception("bootloader 中的 source 指定的目录不存在:", bootloader_args.source)

            # 设置 bootloader 编译输出文件名
            bootloader_args.kernel_output = bootloader.get('kernel_output', '')
            # 设置 bootloader 编译输出文件夹名称
            bootloader_args.build = bootloader.get('build_directory', '')
            # 设置 bootloader 额外参数，如果存在，则将该列表作为 bootloader 选项的输入
            bootloader_args.extra_param = bootloader.get('extra_param', [])
        
        app = ret.get('app')
        # 检查app 中 source 指定的路径是否是一个目录
        app_args.source = app.get('source', '')
        if not app_args.source:
            raise Exception("app 中缺少 source")
        if not os.path.isdir(app_args.source):
            raise Exception("app 中的 source 指定的目录不存在:", app_args.source)

        # 设置 app 编译输出文件名
        app_args.kernel_output = app.get('kernel_output','')
        # 设置 app 编译输出文件夹名称
        app_args.build = app.get('build_directory', "")
        # 设置 app 额外参数，如果存在，则将该列表作为 app 选项的输入
        app_args.extra_param = get_value_with_type_check(app, 'extra_param', [], list)
        # 设置 boards_root 参数，如果存在，则设置 boards_root 参数为 compile.json 中的 boards_root 参数，否则设置为空字符串。
        app_args.boards_root = get_value_with_type_check(ret, 'boards_root', '', str)
        bootloader_args.boards_root = app_args.boards_root
        # 设置 signature_file 参数，如果存在，则设置 signature_file 参数为 compile.json 中的 signature_file 参数，否则设置为空字符串。
        app_args.signature_file = get_value_with_type_check(ret, 'signature_file', '', str)
        bootloader_args.signature_file = app_args.signature_file
        
        bootloader_args.pristine = args.pristine
        app_args.pristine = args.pristine

        if (args.type == 'app'):
            build_app(app_args)
        elif(args.type == 'bootloader'):
            build_bootloader(bootloader_args)
        elif(args.type == 'all'):
            if (0 == build_bootloader(bootloader_args)):
                build_app(app_args)
    except Exception as e:
        print(e)
        exit(-1)

def zephyr_clean(args):
    cfg = read_compile_config(COMPILE_CFG)
    target_list = ['bootloader', 'app']

    for target in target_list:
        if (cfg.get(target) and cfg[target].get('build_directory') and os.path.exists(cfg[target]['build_directory'])):
            shutil.rmtree(cfg[target]['build_directory'])

def zephyr_flash(args):
    cfg = read_compile_config(COMPILE_CFG)
    target_list = []

    if (args.type == 'app' or args.type == 'all'):
        target_list.append('app')
    if (args.type == 'bootloader' or args.type == 'all'):
        target_list.append('bootloader')
    if (len(target_list) == 0):
        raise Exception('请指定需要 flash 的目标')

    for target in target_list:
        if (cfg.get(target) and cfg[target].get('build_directory') and os.path.exists(cfg[target]['build_directory'])):
            if 0 != os.system(' '.join(['west', 'flash', '-r', args.runner,'-d', cfg[target]['build_directory']])):
                break

def add_build_parser(subparsers):
    epilog = ["example:",
              "        # build app for default board",
              "        ztk build\n",
              "        # build bootloader for default board",
              "        ztk build -t bootloader\n",
              "        # build app and bootloader for specific board",
              "        ztk build -b board_name -t all\n",
              "        # export compile.json template",
              "        ztk build --template=compile.json\n"]

    # Add build command.
    parser = subparsers.add_parser('build', formatter_class=argparse.RawTextHelpFormatter, help='build zephyr application', epilog = '\n'.join(epilog))
    cfg = read_compile_config(COMPILE_CFG)
        
    if cfg:
        # If the available_boards parameter exists, it is used as the input for the boards option.
        if not isinstance(cfg.get('available_boards'), list) or len(cfg['available_boards']) == 0:
            raise Exception('available_boards 应该是一个非空列表')
    
        parser.add_argument('-t', '--type', type=str, default='app', choices=['app', 'bootloader', 'all'], help='build type')
        # If there is only one board, the board option is not required, otherwise it is required.
        if (len(cfg['available_boards']) == 1):
            parser.add_argument('-b', '--board', type=str, default=cfg["available_boards"][0], choices=cfg["available_boards"], help= 'available board')
        else:
            parser.add_argument('-b', '--board', type=str, choices=cfg["available_boards"], help='available board')
        parser.add_argument('-p', '--pristine', nargs='?', const='always', default='never', help='pristine build folder setting')
    
    parser.add_argument('--template', metavar='', default='', help='export compile.json template')
    # Set default function to handle command.
    parser.set_defaults(func=zephyr_build)

def add_clean_parser(subparsers):
    parser = subparsers.add_parser('clean', help='clean zephyr application')
    parser.set_defaults(func=zephyr_clean)

def add_flash_parser(subparsers):
    epilog = ["example:",
              "        # flash app",
              "        ztk flash\n",
              "        # flash bootloader",
              "        ztk flash -t bootloader\n",
              "        # flash app and bootloader",
              "        ztk flash -t all\n"]
    parser = subparsers.add_parser('flash', formatter_class=argparse.RawTextHelpFormatter, help='flash zephyr application', epilog='\n'.join(epilog))
    parser.add_argument('-t', '--type', type=str, default='app', choices=['app', 'bootloader', 'all'], help='build type')
    parser.add_argument('-r', '--runner', type=str, default='jlink', choices=['jlink', 'pyocd'], help='runner type')
    parser.set_defaults(func=zephyr_flash)

def add_parser(subparsers):
    add_build_parser(subparsers)
    add_clean_parser(subparsers)
    add_flash_parser(subparsers)