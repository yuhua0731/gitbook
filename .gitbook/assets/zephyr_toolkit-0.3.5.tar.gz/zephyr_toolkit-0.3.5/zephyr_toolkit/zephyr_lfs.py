import argparse
import os
import littlefs
from littlefs import LittleFS

class zephyr_lfs:

    __fs = None

    def __init__(self, cfg):
        self.__fs = LittleFS(
            block_size=cfg.block_size,
            block_count=cfg.block_count,
            read_size=cfg.read_size,
            prog_size=cfg.prog_size,
            name_max=cfg.name_max,
            file_max=cfg.file_max,
            attr_max=cfg.attr_max,
            cache_size=cfg.cache_size,
            lookahead_size=cfg.lookahead_size,
            disk_version = 0x00020000
        )

    def __del__(self):
        pass

    def mount(self, path):
        if littlefs.__version__ == '0.5.0':
            raise Exception("littlefs-python 0.5.0 is not available.")
        
        if not os.path.exists(path):
            raise Exception(f"{path} does not exist")

        # Open image file and read it in binary mode
        with open(path, 'rb') as fh:
            # Create a LittleFS object
            self.__fs.context.buffer = bytearray(fh.read())
            self.__fs.mount()
    
    def __file_copy(self, src, dest):
        # Note: path component separator etc are assumed to be compatible
        # between littlefs and host.
        with open(src, "rb") as infile:
            with self.__fs.open(dest, 'wb') as outfile:
                outfile.write(infile.read())

    def __folder_exist(self, path):
        try:
            return self.__fs.stat(path).type == 2
        except Exception as e:
            return False
    
    def __file_exist(self, path):
        try:
            return self.__fs.stat(path).type == 1
        except Exception as e:
            return False
    def mkdir(self, path):
        self.__fs.mkdir(path)
    
    def directory_copy(self, src, dest, create_src = False):
        if create_src:
            if not dest.endswith('/'):
                dest = dest + '/'
            dest = dest + os.path.basename(src)
            try:
                self.__fs.stat(dest)
            except Exception as e:
                self.__fs.mkdir(dest)
                print(f"mkdir {dest}")
        
        if not dest.endswith('/'):
            dest += '/'

        if os.path.isdir(src):
            for root, dirs, files in os.walk(src):
                for dir in dirs:
                    path = os.path.join(root, dir)
                    relpath = dest + os.path.relpath(path, start=src)
                    print(f"mkdir {relpath}")
                    self.__fs.mkdir(relpath)
                for f in files:
                    path = os.path.join(root, f)
                    abspath = dest + os.path.relpath(path, start=src)
                    print(f"copy {path} to {abspath}")
                    with open(path, "rb") as infile:
                        with self.__fs.open(abspath, "wb") as outfile:
                            outfile.write(infile.read())

    def copy(self, src, dest):
        if self.__file_exist(dest) and (len(src) != 1):
            raise Exception(f"dest is a file, src length not equal to 1 (not copied)")

        for item in src:
            if not os.path.exists(item):
                raise Exception(f"{item} does not exist (not copied)")
            elif os.path.isdir(item):
                raise Exception(f"{item} is a directory (not copied)")
            else:
                # dest is a folder
                if self.__folder_exist(dest):
                    if not dest.endswith('/'):
                        dest = dest + '/'
                    dest = dest + os.path.basename(item)
                # copy file to dest
                self.__file_copy(item, dest)
                print(f"copy {item} to {dest}")

    def copy_recursive(self, src, dest):
        create_src = True
        dest_exist = self.__folder_exist(dest)

        if not dest_exist:
            if len(src) > 1:
                raise Exception(f"{dest} is not a directory")
            
            # src is a file or doesn't exist
            if not os.path.isdir(src[0]) and (len(src) == 1):
                self.copy(src, dest)
                return
            # create dest directory
            self.__fs.mkdir(dest)
            print(f"mkdir {dest}")
            create_src = False
            
        for item in src:
            if os.path.isdir(item):
                self.directory_copy(item, dest, create_src)
            else:
                self.copy(item.split(), dest)
        
    def list(self, path):
        # List all files and directories under the path
        for root, dirs, files in self.__fs.walk(path):
            for dir in dirs:
                print('d ' + os.path.join(root, dir))
            for name in files:
                print('- ' + os.path.join(root, name))
            break

    def export(self, path):
        # Open image file and write it in binary mode
        with open(path, 'wb') as fh:
            fh.write(self.__fs.context.buffer)

def littlefs_path_split(path):
    ret = path.split(':')
    if (len(ret) != 2):
        if (len(ret) == 1):
            ret.append('/')
        else:
            raise Exception('Invalid path')

    if not ret[1]:
        ret[1] = '/'
    return (ret[0], ret[1])

def littlefs_cp(args):
    try:
        fs = zephyr_lfs(args)
        (image,dest) = littlefs_path_split(args.output)
        if os.path.exists(image):
            fs.mount(image)
        fs.copy_recursive(args.inputs, dest) if args.recursive else fs.copy(args.inputs, dest)
        fs.export(image)
    except Exception as e:
        print(e)
        exit(-1)

def littlefs_ls(args):
    try:
        fs = zephyr_lfs(args)
        (image,path) = littlefs_path_split(args.path)
        fs.mount(image)
        fs.list(path)
    except Exception as e:
        print(e)
        exit(-1)

def littlefs_mkdir(args):
    try:
        fs = zephyr_lfs(args)
        (image,path) = littlefs_path_split(args.path)
        if (path == '/'):
            raise Exception('Invalid path')
        fs.mount(image)
        fs.mkdir(path)
        print(f"mkdir {path}")
        fs.export(image)
    except Exception as e:
        print(e)
        exit(-1)

def littlefs_mklfs(args):
    fs = zephyr_lfs(args)
    fs.export(args.output)

def littlefs_add_options(parser):
    parser.add_argument("--block-count", metavar='', type=int, default=225, help='specify the number of blocks in the filesystem. (default: 225)')
    parser.add_argument("--block-size", metavar='', type=int, default=4096, help='specify the size of each block in the filesystem. (default: 4096 bytes)')
    parser.add_argument("--read-size", metavar='', type=int, default=16, help='specify the size of each read operation. (default: 16 bytes)')
    parser.add_argument("--prog-size", metavar='', type=int, default=16, help='specify the program size in bytes for filesystem writes. (default: 16 bytes)')
    parser.add_argument("--cache-size", metavar='', type=int, default=64, help='configure the size of the cache in bytes for performance optimization. (default: 64 bytes)')
    parser.add_argument("--lookahead-size", metavar='', type=int, default=32, help='specify the lookahead size in bytes for read-ahead caching. (default: 32 bytes)')
    # Note: 0 means to use the build-time default.
    parser.add_argument("--name-max", metavar='', type=int, default=255, help='maximum length of filenames. (default: 255)')
    parser.add_argument("--file-max", metavar='', type=int, default=0, help='maximum number of open files. 0 uses the build-time default. (default: 0)')
    parser.add_argument("--attr-max", metavar='', type=int, default=0, help='maximum number of custom attributes. 0 uses the build-time default. (default: 0)')

def littlefs_add_cp_parser(subparsers):
    help = "copy file from host to littlefs image"
    epilog = ["example:",
              "        ztk cp 1.txt 2.txt littlefs.bin",
              "        ztk cp 1.txt littlefs.bin:/2.txt",
              "        ztk cp -r 1.txt folder littlefs.bin",
              "        ztk cp -r folder1 folder2 littlefs.bin"]
    parser = subparsers.add_parser('cp', formatter_class=argparse.RawTextHelpFormatter, help=help, epilog='\n'.join(epilog))
    parser.add_argument("inputs", nargs='+', help="host files or directories")
    parser.add_argument("output", type=str, help="littlefs path")
    parser.add_argument("-r", "--recursive", action="store_true", default=False, help="copy files recursively")
    littlefs_add_options(parser)
    parser.set_defaults(func=littlefs_cp)

def littlefs_add_ls_parser(subparsers):
    help = "list files and directories under the littlefs image"
    epilog = ["example:",
              "        ztk ls littlefs.bin",
              "        ztk ls littlefs.bin:/cfg"]
    
    parser = subparsers.add_parser('ls', formatter_class=argparse.RawTextHelpFormatter, help=help, epilog='\n'.join(epilog) )
    parser.add_argument("path", type=str, help="littlefs path")
    littlefs_add_options(parser)
    parser.set_defaults(func=littlefs_ls)

def littlefs_add_mkdir_parser(subparsers):
    help = "create directory in littlefs image"
    epilog = ["example:",
              "        ztk mkdir littlefs.bin:/cfg"]
    
    parser = subparsers.add_parser('mkdir', formatter_class=argparse.RawTextHelpFormatter, help=help, epilog='\n'.join(epilog) )
    parser.add_argument("path", type=str, help="littlefs path")
    littlefs_add_options(parser)
    parser.set_defaults(func=littlefs_mkdir)

def littlefs_add_mklfs_parser(subparsers):
    help = "create littlefs image"
    epilog = ["example:",
              "        ztk mklfs -o littlefs.bin"]
    parser = subparsers.add_parser('mklfs', formatter_class=argparse.RawTextHelpFormatter, help=help, epilog='\n'.join(epilog) )
    parser.add_argument('-o', "--output", type=str, default='littlefs.bin', help="littlefs image name")
    littlefs_add_options(parser)
    parser.set_defaults(func=littlefs_mklfs)

def add_parser(subparsers):
    littlefs_add_cp_parser(subparsers)
    littlefs_add_ls_parser(subparsers)
    littlefs_add_mkdir_parser(subparsers)
    littlefs_add_mklfs_parser(subparsers)

    
    


   