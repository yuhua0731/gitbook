import canopen
import argparse
from .slcan_devices import slcan_devices as slcan

def select_interface():
    try:
        devices = slcan().available_devices()

        if (len(devices) == 0):
            raise Exception('没有可用的CAN设备')
        elif (len(devices) == 1):
            return devices[0]
        else:
            print('可用的CAN设备:')
            for idx, name in enumerate(devices):
                print(f'{idx}: {name}')
            index = int(input('请选择CAN设备: '))
            if index >= len(devices) or index <= 0:
                raise Exception('输入无效')
            return devices[index]
    except Exception as e:
        print(e)
        exit(-1)

def canopen_lss(args):
    bitrate_dict = {
        1000000   : 0,
        800000    : 1,
        500000    : 2,
        250000    : 3,
        125000    : 4,
        100000    : 5,
        50000     : 6,
        20000     : 7,
        10000     : 8,
    }

    try:
        network = canopen.Network()
        args.interface = args.interface if args.interface else select_interface()
        network.connect(bustype='slcan', channel=args.interface, bitrate=args.bitrate)
        node = network.add_node(args.id)
        # 获取设备的对象字典
        obj_dict = node.object_dictionary
        # 添加0x1018的对象
        object_index_1018 = 0x1018
        object_1018 = canopen.objectdictionary.Array("Identity", object_index_1018)
        # 添加0x01子索引的对象到0x1018对象中
        variable = canopen.objectdictionary.Variable('Vendor-ID', object_index_1018, 1)
        variable.data_type = canopen.objectdictionary.UNSIGNED32
        object_1018.add_member(variable)
        # 添加0x02子索引的对象到0x1018对象中
        variable = canopen.objectdictionary.Variable('Product code', object_index_1018, 2)
        variable.data_type = canopen.objectdictionary.UNSIGNED32
        object_1018.add_member(variable)
        # 添加0x03子索引的对象到0x1018对象中
        variable = canopen.objectdictionary.Variable('Revision number', object_index_1018, 3)
        variable.data_type = canopen.objectdictionary.UNSIGNED32
        object_1018.add_member(variable)
        # 添加0x04子索引的对象到0x1018对象中
        variable = canopen.objectdictionary.Variable('Serial number', object_index_1018, 4)
        variable.data_type = canopen.objectdictionary.UNSIGNED32
        object_1018.add_member(variable)

        # 将0x1018对象添加到设备的对象字典中
        obj_dict.add_object(object_1018)
        
        vendor_id = node.sdo[0x1018][1]
        product_code = node.sdo[0x1018][2]
        revision_version = node.sdo[0x1018][3]
        serial_number = node.sdo[0x1018][4]

        print("Vendor-ID str: ", vendor_id.get_data().decode('utf-8')[::-1])
        print("Vendor-ID int: ", vendor_id.raw)
        print("Product Code int: ", product_code.raw)
        print("Revision Version int: ", revision_version.raw)
        print("Serial Number int: ", serial_number.raw)

        ret_bool = network.lss.send_switch_state_selective(vendor_id.raw, product_code.raw, revision_version.raw, serial_number.raw)

        if ret_bool:
            if args.lss_id is not None:
                network.lss.configure_node_id(args.lss_id)
            if args.lss_bitrate is not None:
                network.lss.configure_bit_timing(bitrate_dict[args.lss_bitrate])
            network.lss.store_configuration()
            network.lss.send_switch_state_global(network.lss.WAITING_STATE)

        node.nmt.state = 'RESET'
    except Exception as e:
        print(e)
        exit(-1)

def add_parser(subparsers):
    epilog = ["example:",
              "         # set bitrate to 250000 and node id to 2",
              "         ztk lss 1 500000 -i 2 -b 250000\n"]
    parser = subparsers.add_parser('lss', formatter_class=argparse.RawTextHelpFormatter, help='canopen layer setting service', epilog='\n'.join(epilog))
    parser.add_argument('id', type=int, help='id of the node')
    parser.add_argument('bitrate', type=int, help='bitrate for the can bus')
    parser.add_argument('-p', '--interface', type=str, help='interface for slcan', metavar='')
    parser.add_argument('-i', '--lss-id', type=int, help='id to be set by lss', metavar='')
    parser.add_argument('-b', '--lss-bitrate', type=int, help='bitrate to be set by lss', metavar='')
    parser.set_defaults(func=canopen_lss)