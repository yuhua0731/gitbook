
import sys
import argparse
from . import zephyr_settings
from . import zephyr_lfs
from . import zephyr_build
from . import canopen_lss
from . import slcan_devices

def main():
    parser = argparse.ArgumentParser(description='Zephyr Tool Kit')  
    subparsers = parser.add_subparsers(title='extension commands for zephyr')
    zephyr_build.add_parser(subparsers)
    zephyr_settings.add_parser(subparsers)
    zephyr_lfs.add_parser(subparsers)
    slcan_devices.add_parser(subparsers)
    canopen_lss.add_parser(subparsers)
    args = parser.parse_args()

    if (len(vars(args)) == 0):
        parser.print_help()
        return

    if hasattr(args, 'func'):
        args.func(args)

if __name__ == '__main__':
    main()
