from setuptools import setup, find_packages  

setup(  
    name='zephyr_toolkit', 
    version='0.3.5',
    packages=find_packages(),
    install_requires=[
        'west>=1.0.0',
        'littlefs-python>=0.9.0',
        'python-can',
        'pyserial'
    ],

    entry_points={  
        'console_scripts': [  
            'ztk=zephyr_toolkit.__main__:main',  
        ],
    },

    include_package_data=True,

    classifiers=[
        'Programming Language :: Python :: 3',  
        'License :: OSI Approved :: MIT License',  
        'Operating System :: OS Independent',  
    ],
)